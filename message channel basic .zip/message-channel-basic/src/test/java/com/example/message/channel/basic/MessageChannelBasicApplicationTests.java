package com.example.message.channel.basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageChannelBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}

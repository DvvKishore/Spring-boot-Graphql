package com.example.message.channel.basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessageChannelBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessageChannelBasicApplication.class, args);
	}

}
